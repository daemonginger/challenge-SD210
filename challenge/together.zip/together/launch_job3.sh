cd /cal/homes/aturquetil/challenge/together
/cal/homes/aturquetil/anaconda3/bin/python job3.py $1 $2 $3

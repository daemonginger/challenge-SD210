cd /cal/homes/aturquetil/challenge/together
/cal/homes/aturquetil/anaconda3/bin/python job_sub.py $1 $2 $3

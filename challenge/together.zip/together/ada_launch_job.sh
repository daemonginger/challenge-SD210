cd /cal/homes/aturquetil/challenge/together
/cal/homes/aturquetil/anaconda3/bin/python ada_job.py $1 $2 $3 $4
